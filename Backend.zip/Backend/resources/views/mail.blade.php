<table border='1'>
    <tr>
        <td>
            Verification Code
        </td>
        <td>
            {{$code}}
        </td>
    <tr>
</table>